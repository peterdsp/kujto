Kujto Studio press kit
======================

What's in here
--------------
  BOILERPLATE.txt       The company/product boilerplate, plain text.
  FACT-SHEET.txt        The fact sheet as an aligned column layout.
  README.txt            This file.
  logos/
    app-icon-1024.png   Primary app icon at native size, 1024 x 1024.
    touch-icon.png      Apple touch icon, 180 x 180.
    favicon-192.png     Web favicon, 192 x 192.
  screenshots/
    01-before-you-touch-this-file.jpeg
    02-memory-linter.jpeg
    03-multi-agent-wire.jpeg
    04-xcode-extension.jpeg
    05-vscode-cursor.jpeg
    06-menu-bar.jpeg
                        Retina App Store shots, each 2880 x 1800.

How to use these assets
-----------------------
Reproduce logos and screenshots as-is. Do not recolor, distort,
place on a busy background, or overlay other marks. If you need a
different crop or a transparent variant, email and we'll cut one.

Boilerplate is drop-in. Please quote the fact sheet numbers verbatim
so they stay accurate across coverage.

Press contact
-------------
Petros Dhespollari, maker of Kujto Studio
press@peterdsp.dev
Europe (CET). Interviews and review copies on request.

Website: https://kujto.peterdsp.dev/press.html
